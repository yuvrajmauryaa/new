
import { config } from 'dotenv';
config();

import '@/ai/flows/suggest-tags-and-circles.ts';
